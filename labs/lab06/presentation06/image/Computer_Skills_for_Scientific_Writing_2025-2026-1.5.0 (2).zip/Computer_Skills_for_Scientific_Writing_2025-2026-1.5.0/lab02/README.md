## Лабораторная работа 1: [rutube](https://rutube.ru/video/private/ed7151ee8c2cccb41662ab928aebd271/?p=uGTD3jk-frF6I-wJU7t3EQ)
## Подготовка отчёта 1: [rutube](https://rutube.ru/video/private/ed7151ee8c2cccb41662ab928aebd271/?p=uGTD3jk-frF6I-wJU7t3EQ)
## Подготовка презентации 1: [youtube](https://youtu.be/qtxEH34xaxU)
## Защита презентации 1: [youtube](https://youtu.be/qtxEH34xaxU)
