## Лабораторная работа 1: [rutube](https://rutube.ru/plst/602561)
## Подготовка отчёта 1: [rutube](https://rutube.ru/plst/602561)
## Подготовка презентации 1: [rutube](https://rutube.ru/plst/602561)
## Защита презентации 1: [rutube](https://rutube.ru/plst/602561)