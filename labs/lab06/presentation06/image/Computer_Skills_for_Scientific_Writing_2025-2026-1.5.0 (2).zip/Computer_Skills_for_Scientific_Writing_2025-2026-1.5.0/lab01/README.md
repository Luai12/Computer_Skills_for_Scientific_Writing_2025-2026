## Лабораторная работа 1: [rutube](https://rutube.ru/video/private/55b2b8a8a22cf19cf4276bb1c662b396/?p=U09gf4nxHwPRLZ1f_wpG9Q)
## Подготовка отчёта 1: [rutube](https://rutube.ru/video/private/55b2b8a8a22cf19cf4276bb1c662b396/?p=U09gf4nxHwPRLZ1f_wpG9Q)
## Подготовка презентации 1: [youtu](https://youtu.be/Nplhg-Xm970)
## Защита презентации 1: [youtu](https://youtu.be/Nplhg-Xm970)