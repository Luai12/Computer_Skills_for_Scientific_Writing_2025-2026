## Снкасты

- [Rutube]
    - [Выполнение лабораторной работы](https://rutube.ru/video/private/3fdf39343d0a97aced486ece0ec4cdea/?p=HRi2myZ4dzFJJtBq_At-xw)
    - [защиты презентации лабораторной работы](https://rutube.ru/video/private/51e8842062892d059f52b0554903b30e/?p=bI0UIxXGNsOsIxSB1FIkgg)

