## Снкасты

- [Rutube](https://rutube.ru/plst/114257/)
    - [Выполнение лабораторной работы](https://rutube.ru/video/private/5d9435b8b154af64ee1ad0b5398a579d/?p=uS0gD-16LhuwUDcBlLc8kg)
    - [скринкаст процесса подготовки отчёта](https://rutube.ru/video/private/95e03333f0aac081aac53de29c6afacd/?p=Zq3ujcAZZDWZUh9SQFClqA)
    - [скринкаст процесса подготовки презентации](https://rutube.ru/video/private/b6736048259bf9c68c52a91fd177f612/?p=9mUnSw946m8wXxjqMeQHGQ)
    - [Защита лабораторной работы](https://rutube.ru/video/private/a01cc1eda2eda9495198deee8070fa02/?p=EiyzUSH2cGcxUDcBzo3agw)

НА Платформе:
     -[Выполнение лабораторной работы](https://plvideo.ru/watch?v=yDsp62x3wMMB)
    - [скринкаст процесса подготовки отчёта](https://plvideo.ru/watch?v=AashZEiLE94W)
    - [скринкаст процесса подготовки презентации](https://plvideo.ru/watch?v=fFJHHRhTjG5w)
    - [Защита лабораторной работы](https://plvideo.ru/watch?v=ccu100MKiDPx)

